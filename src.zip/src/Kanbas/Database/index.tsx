import courses from "./courses.json";
import modules from "./modules.json";
import assignments from "./assignments.json";

export { courses, modules, assignments };